// Email & Proxy Checker - Client-side JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Form validation helpers
    setupFormValidation();
    
    // Auto-refresh for progress pages
    setupAutoRefresh();
    
    // Textarea auto-resize
    setupTextareaResize();
});

function setupFormValidation() {
    // Email format validation
    const emailTextareas = document.querySelectorAll('textarea[name="emails"]');
    emailTextareas.forEach(function(textarea) {
        textarea.addEventListener('blur', function() {
            validateEmailFormat(this);
        });
    });

    // Proxy format validation
    const proxyTextareas = document.querySelectorAll('textarea[name="proxies"]');
    proxyTextareas.forEach(function(textarea) {
        textarea.addEventListener('blur', function() {
            validateProxyFormat(this);
        });
    });

    // Protocol selection validation
    const protocolCheckboxes = document.querySelectorAll('input[name="protocols"]');
    protocolCheckboxes.forEach(function(checkbox) {
        checkbox.addEventListener('change', function() {
            validateProtocolSelection();
        });
    });
}

function validateEmailFormat(textarea) {
    const lines = textarea.value.trim().split('\n');
    let validCount = 0;
    let invalidLines = [];

    lines.forEach(function(line, index) {
        const trimmedLine = line.trim();
        if (trimmedLine) {
            if (trimmedLine.includes(':')) {
                const parts = trimmedLine.split(':');
                const email = parts[0].trim();
                if (isValidEmail(email) && parts[1]) {
                    validCount++;
                } else {
                    invalidLines.push(index + 1);
                }
            } else {
                invalidLines.push(index + 1);
            }
        }
    });

    updateValidationStatus(textarea, validCount > 0, 
        invalidLines.length > 0 ? `Неверный формат в строках: ${invalidLines.join(', ')}` : '');
    
    return validCount > 0;
}

function validateProxyFormat(textarea) {
    const lines = textarea.value.trim().split('\n');
    let validCount = 0;
    let invalidLines = [];

    lines.forEach(function(line, index) {
        const trimmedLine = line.trim();
        if (trimmedLine) {
            if (trimmedLine.includes(':')) {
                const parts = trimmedLine.split(':');
                const host = parts[0].trim();
                const port = parts[1].trim();
                if (host && port && !isNaN(port) && parseInt(port) > 0 && parseInt(port) < 65536) {
                    validCount++;
                } else {
                    invalidLines.push(index + 1);
                }
            } else {
                invalidLines.push(index + 1);
            }
        }
    });

    updateValidationStatus(textarea, validCount > 0,
        invalidLines.length > 0 ? `Неверный формат в строках: ${invalidLines.join(', ')}` : '');
    
    return validCount > 0;
}

function validateProtocolSelection() {
    const checkboxes = document.querySelectorAll('input[name="protocols"]:checked');
    const protocolSection = document.querySelector('input[name="protocols"]').closest('.mb-4');
    
    if (checkboxes.length === 0) {
        protocolSection.classList.add('has-error');
        showValidationMessage(protocolSection, 'Выберите хотя бы один протокол');
        return false;
    } else {
        protocolSection.classList.remove('has-error');
        hideValidationMessage(protocolSection);
        return true;
    }
}

function updateValidationStatus(element, isValid, message) {
    if (isValid) {
        element.classList.remove('is-invalid');
        element.classList.add('is-valid');
        hideValidationMessage(element);
    } else {
        element.classList.remove('is-valid');
        element.classList.add('is-invalid');
        showValidationMessage(element, message);
    }
}

function showValidationMessage(element, message) {
    hideValidationMessage(element);
    const feedback = document.createElement('div');
    feedback.className = 'invalid-feedback';
    feedback.textContent = message;
    element.parentNode.appendChild(feedback);
}

function hideValidationMessage(element) {
    const parent = element.parentNode;
    const existingFeedback = parent.querySelector('.invalid-feedback');
    if (existingFeedback) {
        existingFeedback.remove();
    }
}

function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function setupAutoRefresh() {
    // Check if we're on a progress page
    const progressPage = document.querySelector('[data-auto-refresh]');
    if (progressPage) {
        const interval = progressPage.dataset.autoRefresh || 3000;
        setTimeout(function() {
            window.location.reload();
        }, parseInt(interval));
    }
}

function setupTextareaResize() {
    const textareas = document.querySelectorAll('textarea');
    textareas.forEach(function(textarea) {
        // Auto-resize functionality
        textarea.addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = this.scrollHeight + 'px';
        });

        // Line counter
        const lineCounter = document.createElement('small');
        lineCounter.className = 'text-muted mt-1 d-block';
        lineCounter.textContent = 'Строк: 0';
        textarea.parentNode.appendChild(lineCounter);

        textarea.addEventListener('input', function() {
            const lines = this.value.split('\n').length;
            const nonEmptyLines = this.value.split('\n').filter(line => line.trim()).length;
            lineCounter.textContent = `Строк: ${lines} (заполнено: ${nonEmptyLines})`;
        });
    });
}

// Utility functions
function showAlert(message, type = 'info') {
    const alertContainer = document.querySelector('.container');
    const alert = document.createElement('div');
    alert.className = `alert alert-${type} alert-dismissible fade show`;
    alert.innerHTML = `
        <i class="fas fa-info-circle me-2"></i>
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    const firstChild = alertContainer.firstElementChild;
    alertContainer.insertBefore(alert, firstChild);
    
    // Auto-dismiss after 5 seconds
    setTimeout(function() {
        if (alert.parentNode) {
            alert.classList.remove('show');
            setTimeout(function() {
                if (alert.parentNode) {
                    alert.remove();
                }
            }, 150);
        }
    }, 5000);
}

function copyToClipboard(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(function() {
            showAlert('Скопировано в буфер обмена', 'success');
        }).catch(function() {
            fallbackCopyToClipboard(text);
        });
    } else {
        fallbackCopyToClipboard(text);
    }
}

function fallbackCopyToClipboard(text) {
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.left = '-999999px';
    textArea.style.top = '-999999px';
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    
    try {
        document.execCommand('copy');
        showAlert('Скопировано в буфер обмена', 'success');
    } catch (err) {
        showAlert('Не удалось скопировать', 'error');
    }
    
    document.body.removeChild(textArea);
}

// Export functionality
function exportTableToCSV(tableId, filename) {
    const table = document.getElementById(tableId);
    if (!table) return;
    
    let csv = [];
    const rows = table.querySelectorAll('tr');
    
    rows.forEach(function(row) {
        const cols = row.querySelectorAll('td, th');
        const rowData = Array.from(cols).map(col => {
            return '"' + col.textContent.replace(/"/g, '""') + '"';
        });
        csv.push(rowData.join(','));
    });
    
    const csvContent = csv.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    
    const link = document.createElement('a');
    if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
}

// Form submission helpers
function showLoadingState(button, loadingText) {
    if (button.dataset.originalText === undefined) {
        button.dataset.originalText = button.innerHTML;
    }
    button.innerHTML = `<i class="fas fa-spinner fa-spin me-2"></i>${loadingText}`;
    button.disabled = true;
}

function hideLoadingState(button) {
    if (button.dataset.originalText) {
        button.innerHTML = button.dataset.originalText;
        button.disabled = false;
    }
}

// Handle form submissions with loading states
document.addEventListener('submit', function(e) {
    const form = e.target;
    if (form.tagName === 'FORM') {
        const submitButton = form.querySelector('button[type="submit"]');
        if (submitButton) {
            showLoadingState(submitButton, 'Обработка...');
        }
    }
});
