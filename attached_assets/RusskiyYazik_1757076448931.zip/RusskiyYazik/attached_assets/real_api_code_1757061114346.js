// Конфигурация приложения
const AppConfig = {
    endpoints: {
        emailCheck: 'http://localhost:3000/api/check-email',
        proxyCheck: 'http://localhost:3000/api/check-proxy', 
        parsing: 'http://localhost:3000/api/parse-data',
        pop3: 'http://localhost:3000/api/pop3',
        smtp: 'http://localhost:3000/api/smtp',
        imap: 'http://localhost:3000/api/imap'
    },
    providers: {
        hotmail: {
            pop3: 'outlook.office365.com:995',
            smtp: 'smtp.live.com:587',
            imap: 'outlook.office365.com:993'
        },
        yahoo: {
            pop3: 'pop.mail.yahoo.com:995',
            smtp: 'smtp.mail.yahoo.com:587', 
            imap: 'imap.mail.yahoo.com:993'
        }
    }
};

// Основной класс приложения
class EmailAccountManager {
    constructor() {
        this.data = {
            emails: [],
            proxies: [],
            parsedData: [],
            currentProxy: null,
            isRunning: false
        };
        this.stats = {
            loaded: 0,
            checked: 0,
            good: 0,
            bad: 0,
            invalid: 0
        };
    }

    // Реальная отправка HTTP запросов
    async sendApiRequest(url, method = 'GET', data = null, headers = {}) {
        const config = {
            method: method,
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                ...headers
            }
        };

        if (data && (method === 'POST' || method === 'PUT')) {
            config.body = JSON.stringify(data);
        }

        try {
            const response = await fetch(url, config);
            const responseData = await response.json();
            
            this.logToTerminal(`[API] ${method} ${url} - Status: ${response.status}`);
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${responseData.message || 'Request failed'}`);
            }
            
            return responseData;
        } catch (error) {
            this.logToTerminal(`[ERROR] API Request failed: ${error.message}`);
            throw error;
        }
    }

    // Загрузка файлов с email аккаунтами
    loadEmailFile(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (e) => {
                try {
                    const content = e.target.result;
                    const lines = content.split('\n').filter(line => line.trim());
                    
                    this.data.emails = [];
                    lines.forEach((line, index) => {
                        const parts = line.split(':');
                        if (parts.length >= 2) {
                            this.data.emails.push({
                                id: index,
                                email: parts[0].trim(),
                                password: parts[1].trim(),
                                provider: this.detectProvider(parts[0].trim()),
                                status: 'unchecked'
                            });
                        }
                    });
                    
                    this.stats.loaded = this.data.emails.length;
                    this.logToTerminal(`[FILE] Loaded ${this.data.emails.length} email accounts`);
                    resolve(this.data.emails);
                } catch (error) {
                    this.logToTerminal(`[ERROR] Failed to load email file: ${error.message}`);
                    reject(error);
                }
            };
            reader.onerror = () => reject(new Error('File reading failed'));
            reader.readAsText(file);
        });
    }

    // Определение провайдера email
    detectProvider(email) {
        const domain = email.split('@')[1]?.toLowerCase();
        if (domain?.includes('hotmail') || domain?.includes('outlook') || domain?.includes('live')) {
            return 'hotmail';
        }
        if (domain?.includes('yahoo')) {
            return 'yahoo';
        }
        return 'unknown';
    }

    // Реальная проверка email аккаунтов
    async checkEmailAccounts(protocols = ['pop3']) {
        if (this.data.isRunning) {
            throw new Error('Check already in progress');
        }

        if (this.data.emails.length === 0) {
            throw new Error('No email accounts loaded');
        }

        this.data.isRunning = true;
        this.stats.checked = 0;
        this.stats.good = 0;
        this.stats.bad = 0;
        this.stats.invalid = 0;

        this.logToTerminal(`[CHECK] Starting check of ${this.data.emails.length} accounts`);

        for (const account of this.data.emails) {
            if (!this.data.isRunning) break;

            try {
                const result = await this.checkSingleAccount(account, protocols);
                account.status = result.status;
                account.lastCheck = new Date().toISOString();
                
                this.stats.checked++;
                if (result.status === 'good') this.stats.good++;
                else if (result.status === 'bad') this.stats.bad++;
                else this.stats.invalid++;

                this.logToTerminal(`[CHECK] ${account.email} - ${result.status.toUpperCase()}`);
                this.updateUI();

            } catch (error) {
                account.status = 'error';
                this.stats.invalid++;
                this.logToTerminal(`[ERROR] ${account.email} - ${error.message}`);
            }

            // Задержка между проверками
            await this.sleep(1000);
        }

        this.data.isRunning = false;
        this.logToTerminal('[CHECK] All accounts checked');
    }

    // Проверка одного аккаунта
    async checkSingleAccount(account, protocols) {
        const provider = AppConfig.providers[account.provider];
        if (!provider) {
            throw new Error(`Unknown provider: ${account.provider}`);
        }

        const checkData = {
            email: account.email,
            password: account.password,
            provider: account.provider,
            protocols: protocols,
            servers: provider,
            proxy: this.data.currentProxy
        };

        // Выбираем API endpoint в зависимости от протокола
        let endpoint = AppConfig.endpoints.emailCheck;
        if (protocols.includes('pop3')) {
            endpoint = AppConfig.endpoints.pop3;
        } else if (protocols.includes('smtp')) {
            endpoint = AppConfig.endpoints.smtp;
        } else if (protocols.includes('imap')) {
            endpoint = AppConfig.endpoints.imap;
        }

        return await this.sendApiRequest(endpoint, 'POST', checkData);
    }

    // Загрузка proxy серверов
    async loadProxyFile(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (e) => {
                try {
                    const content = e.target.result;
                    const lines = content.split('\n').filter(line => line.trim());
                    
                    this.data.proxies = [];
                    lines.forEach((line, index) => {
                        const parts = line.trim().split(':');
                        if (parts.length >= 2) {
                            this.data.proxies.push({
                                id: index,
                                host: parts[0],
                                port: parts[1],
                                username: parts[2] || null,
                                password: parts[3] || null,
                                type: 'socks5', // default
                                status: 'unchecked'
                            });
                        }
                    });
                    
                    this.logToTerminal(`[PROXY] Loaded ${this.data.proxies.length} proxy servers`);
                    resolve(this.data.proxies);
                } catch (error) {
                    reject(error);
                }
            };
            reader.readAsText(file);
        });
    }

    // Проверка proxy серверов
    async checkProxyServers() {
        if (this.data.proxies.length === 0) {
            throw new Error('No proxy servers loaded');
        }

        this.logToTerminal(`[PROXY] Starting check of ${this.data.proxies.length} proxies`);

        for (const proxy of this.data.proxies) {
            try {
                const result = await this.sendApiRequest(
                    AppConfig.endpoints.proxyCheck, 
                    'POST', 
                    {
                        host: proxy.host,
                        port: proxy.port,
                        username: proxy.username,
                        password: proxy.password,
                        type: proxy.type
                    }
                );

                proxy.status = result.working ? 'good' : 'bad';
                proxy.responseTime = result.responseTime;
                proxy.country = result.country;

                this.logToTerminal(`[PROXY] ${proxy.host}:${proxy.port} - ${proxy.status.toUpperCase()}`);
                
            } catch (error) {
                proxy.status = 'error';
                this.logToTerminal(`[ERROR] Proxy check failed: ${error.message}`);
            }

            await this.sleep(500);
        }
    }

    // Парсинг данных
    async startParsing(config) {
        const parsingData = {
            keywords: config.keywords.split(',').map(k => k.trim()),
            account: {
                email: config.email,
                password: config.password
            },
            period: config.period,
            count: config.count,
            proxy: this.data.currentProxy
        };

        try {
            const result = await this.sendApiRequest(
                AppConfig.endpoints.parsing,
                'POST',
                parsingData
            );

            this.data.parsedData.push(...result.data);
            this.logToTerminal(`[PARSING] Found ${result.data.length} new items`);
            
            return result;
        } catch (error) {
            this.logToTerminal(`[ERROR] Parsing failed: ${error.message}`);
            throw error;
        }
    }

    // Экспорт результатов
    exportResults(type = 'email') {
        let data, filename;
        
        switch (type) {
            case 'email':
                data = this.data.emails.filter(acc => acc.status === 'good');
                filename = `good_emails_${Date.now()}.txt`;
                break;
            case 'proxy':
                data = this.data.proxies.filter(proxy => proxy.status === 'good');
                filename = `good_proxies_${Date.now()}.txt`;
                break;
            case 'parsed':
                data = this.data.parsedData;
                filename = `parsed_data_${Date.now()}.json`;
                break;
        }

        if (data.length === 0) {
            alert('No data to export');
            return;
        }

        let content;
        if (type === 'email') {
            content = data.map(acc => `${acc.email}:${acc.password}`).join('\n');
        } else if (type === 'proxy') {
            content = data.map(proxy => 
                `${proxy.host}:${proxy.port}${proxy.username ? `:${proxy.username}:${proxy.password}` : ''}`
            ).join('\n');
        } else {
            content = JSON.stringify(data, null, 2);
        }

        this.downloadFile(content, filename);
        this.logToTerminal(`[EXPORT] Exported ${data.length} items to ${filename}`);
    }

    // Скачивание файла
    downloadFile(content, filename) {
        const blob = new Blob([content], { type: 'text/plain' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
    }

    // Остановка всех процессов
    stopAllProcesses() {
        this.data.isRunning = false;
        this.logToTerminal('[SYSTEM] All processes stopped by user');
    }

    // Очистка данных
    clearData(type = 'all') {
        switch (type) {
            case 'email':
                this.data.emails = [];
                this.stats = { loaded: 0, checked: 0, good: 0, bad: 0, invalid: 0 };
                break;
            case 'proxy':
                this.data.proxies = [];
                break;
            case 'parsed':
                this.data.parsedData = [];
                break;
            case 'all':
                this.data = { emails: [], proxies: [], parsedData: [], currentProxy: null, isRunning: false };
                this.stats = { loaded: 0, checked: 0, good: 0, bad: 0, invalid: 0 };
                break;
        }
        
        this.logToTerminal(`[CLEAR] Cleared ${type} data`);
        this.updateUI();
    }

    // Установка текущего proxy
    setCurrentProxy(proxyId) {
        const proxy = this.data.proxies.find(p => p.id === proxyId);
        if (proxy && proxy.status === 'good') {
            this.data.currentProxy = proxy;
            this.logToTerminal(`[PROXY] Set current proxy: ${proxy.host}:${proxy.port}`);
        }
    }

    // Логирование в терминал
    logToTerminal(message) {
        const timestamp = new Date().toLocaleTimeString();
        console.log(`[${timestamp}] ${message}`);
        
        // Если есть элемент терминала на странице
        const terminal = document.getElementById('mainTerminal');
        if (terminal) {
            terminal.innerHTML += `<br>[${timestamp}] ${message}`;
            terminal.scrollTop = terminal.scrollHeight;
        }
    }

    // Обновление UI (переопределить в зависимости от интерфейса)
    updateUI() {
        // Обновление статистики
        if (document.getElementById('emailLoaded')) {
            document.getElementById('emailLoaded').textContent = this.stats.loaded;
            document.getElementById('emailChecked').textContent = this.stats.checked;
            document.getElementById('emailGood').textContent = this.stats.good;
            document.getElementById('emailBad').textContent = this.stats.bad;
            document.getElementById('emailInvalid').textContent = this.stats.invalid;
        }

        // Обновление списков аккаунтов
        this.updateEmailList();
        this.updateProxyList();
    }

    // Обновление списка email
    updateEmailList() {
        const container = document.getElementById('emailAccountList');
        if (!container) return;

        container.innerHTML = '';
        this.data.emails.forEach(account => {
            const div = document.createElement('div');
            div.className = `account-item status-${account.status}`;
            div.innerHTML = `
                <span>${account.email}</span>
                <span>${account.status.toUpperCase()}</span>
            `;
            container.appendChild(div);
        });
    }

    // Обновление списка proxy
    updateProxyList() {
        const container = document.getElementById('proxyList');
        if (!container) return;

        container.innerHTML = '';
        this.data.proxies.forEach(proxy => {
            const div = document.createElement('div');
            div.className = `account-item status-${proxy.status}`;
            div.innerHTML = `
                <span>${proxy.host}:${proxy.port}</span>
                <span>${proxy.status.toUpperCase()}</span>
                <button onclick="app.setCurrentProxy(${proxy.id})" ${proxy.status !== 'good' ? 'disabled' : ''}>
                    Use
                </button>
            `;
            container.appendChild(div);
        });
    }

    // Вспомогательная функция задержки
    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

// API функции для интеграции с сервером
class ServerAPI {
    constructor(baseUrl = 'http://localhost:3000/api') {
        this.baseUrl = baseUrl;
        this.token = null;
    }

    // Авторизация
    async authenticate(apiKey) {
        try {
            const response = await fetch(`${this.baseUrl}/auth`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ apiKey })
            });
            
            const data = await response.json();
            this.token = data.token;
            return data;
        } catch (error) {
            throw new Error(`Authentication failed: ${error.message}`);
        }
    }

    // Проверка email через POP3
    async checkEmailPOP3(email, password, server) {
        return await this.request('/check-pop3', {
            email, password, server
        });
    }

    // Проверка email через SMTP
    async checkEmailSMTP(email, password, server) {
        return await this.request('/check-smtp', {
            email, password, server
        });
    }

    // Проверка email через IMAP
    async checkEmailIMAP(email, password, server) {
        return await this.request('/check-imap', {
            email, password, server
        });
    }

    // Проверка proxy
    async checkProxy(host, port, type, username, password) {
        return await this.request('/check-proxy', {
            host, port, type, username, password
        });
    }

    // Базовый метод для запросов
    async request(endpoint, data) {
        const response = await fetch(`${this.baseUrl}${endpoint}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': this.token ? `Bearer ${this.token}` : ''
            },
            body: JSON.stringify(data)
        });

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }

        return await response.json();
    }
}

// Инициализация приложения
const app = new EmailAccountManager();
const serverAPI = new ServerAPI();

// Пример использования:
/*
// Загрузка файла с email аккаунтами
document.getElementById('emailFile').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (file) {
        try {
            await app.loadEmailFile(file);
            app.updateUI();
        } catch (error) {
            alert('Ошибка загрузки файла: ' + error.message);
        }
    }
});

// Запуск проверки email
document.getElementById('startCheck').addEventListener('click', async () => {
    try {
        const protocols = [];
        if (document.getElementById('enablePOP3').checked) protocols.push('pop3');
        if (document.getElementById('enableSMTP').checked) protocols.push('smtp');
        if (document.getElementById('enableIMAP').checked) protocols.push('imap');
        
        await app.checkEmailAccounts(protocols);
    } catch (error) {
        alert('Ошибка проверки: ' + error.message);
    }
});

// Остановка проверки
document.getElementById('stopCheck').addEventListener('click', () => {
    app.stopAllProcesses();
});

// Экспорт результатов
document.getElementById('exportEmails').addEventListener('click', () => {
    app.exportResults('email');
});
*/