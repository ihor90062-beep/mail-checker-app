const express = require('express');
const cors = require('cors');
const nodemailer = require('nodemailer');
const { ImapFlow } = require('imapflow');
const net = require('net');
const https = require('https');
const http = require('http');
const { SocksProxyAgent } = require('socks-proxy-agent');
const { HttpsProxyAgent } = require('https-proxy-agent');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const helmet = require('helmet');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'your-super-secret-key';

// Middlewares
app.use(helmet());
app.use(cors());
app.use(express.json({ limit: '10mb' }));

// Rate limiting
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 1000, // limit each IP to 1000 requests per windowMs
    message: 'Too many requests from this IP'
});
app.use('/api/', limiter);

// Database initialization
const db = new sqlite3.Database('./email_checker.db');

db.serialize(() => {
    // Users table
    db.run(`CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        api_key TEXT UNIQUE,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        is_active BOOLEAN DEFAULT 1
    )`);

    // Email accounts table
    db.run(`CREATE TABLE IF NOT EXISTS email_accounts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        email TEXT NOT NULL,
        password TEXT NOT NULL,
        provider TEXT,
        status TEXT DEFAULT 'unchecked',
        pop3_status TEXT,
        smtp_status TEXT,
        imap_status TEXT,
        last_check DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id)
    )`);

    // Proxy servers table
    db.run(`CREATE TABLE IF NOT EXISTS proxy_servers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        host TEXT NOT NULL,
        port INTEGER NOT NULL,
        username TEXT,
        password TEXT,
        type TEXT DEFAULT 'http',
        status TEXT DEFAULT 'unchecked',
        response_time INTEGER,
        country TEXT,
        last_check DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id)
    )`);

    // Check results table
    db.run(`CREATE TABLE IF NOT EXISTS check_results (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        email TEXT,
        protocol TEXT,
        status TEXT,
        error_message TEXT,
        response_time INTEGER,
        proxy_used TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id)
    )`);
});

// Authentication middleware
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({ error: 'Access token required' });
    }

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) return res.status(403).json({ error: 'Invalid token' });
        req.user = user;
        next();
    });
};

// Real POP3 checker
class POP3Checker {
    static async checkAccount(email, password, server, proxy = null) {
        const startTime = Date.now();
        
        return new Promise((resolve, reject) => {
            const [host, port] = server.split(':');
            const socket = net.createConnection({
                host: host,
                port: parseInt(port) || 995
            });

            let buffer = '';
            let step = 0;
            const commands = [
                `USER ${email}`,
                `PASS ${password}`,
                'STAT',
                'QUIT'
            ];

            socket.on('connect', () => {
                console.log(`POP3: Connected to ${host}:${port}`);
            });

            socket.on('data', (data) => {
                buffer += data.toString();
                const lines = buffer.split('\r\n');
                
                for (let i = 0; i < lines.length - 1; i++) {
                    const line = lines[i];
                    console.log(`POP3 Response: ${line}`);

                    if (line.startsWith('+OK')) {
                        if (step < commands.length) {
                            socket.write(commands[step] + '\r\n');
                            step++;
                            if (step === 3) { // After STAT command
                                const responseTime = Date.now() - startTime;
                                resolve({
                                    status: 'good',
                                    protocol: 'pop3',
                                    server: server,
                                    responseTime: responseTime,
                                    message: 'POP3 authentication successful'
                                });
                                socket.destroy();
                                return;
                            }
                        }
                    } else if (line.startsWith('-ERR')) {
                        const responseTime = Date.now() - startTime;
                        resolve({
                            status: 'bad',
                            protocol: 'pop3',
                            server: server,
                            responseTime: responseTime,
                            message: line
                        });
                        socket.destroy();
                        return;
                    }
                }
                
                buffer = lines[lines.length - 1];
            });

            socket.on('error', (err) => {
                const responseTime = Date.now() - startTime;
                resolve({
                    status: 'error',
                    protocol: 'pop3',
                    server: server,
                    responseTime: responseTime,
                    message: err.message
                });
            });

            socket.setTimeout(30000, () => {
                socket.destroy();
                resolve({
                    status: 'timeout',
                    protocol: 'pop3',
                    server: server,
                    responseTime: 30000,
                    message: 'Connection timeout'
                });
            });
        });
    }
}

// Real SMTP checker
class SMTPChecker {
    static async checkAccount(email, password, server, proxy = null) {
        const startTime = Date.now();
        const [host, port] = server.split(':');

        try {
            const transporter = nodemailer.createTransporter({
                host: host,
                port: parseInt(port) || 587,
                secure: parseInt(port) === 465,
                auth: {
                    user: email,
                    pass: password
                },
                connectionTimeout: 30000,
                greetingTimeout: 30000,
                socketTimeout: 30000
            });

            await transporter.verify();
            const responseTime = Date.now() - startTime;

            return {
                status: 'good',
                protocol: 'smtp',
                server: server,
                responseTime: responseTime,
                message: 'SMTP authentication successful'
            };

        } catch (error) {
            const responseTime = Date.now() - startTime;
            return {
                status: 'bad',
                protocol: 'smtp',
                server: server,
                responseTime: responseTime,
                message: error.message
            };
        }
    }
}

// Real IMAP checker
class IMAPChecker {
    static async checkAccount(email, password, server, proxy = null) {
        const startTime = Date.now();
        const [host, port] = server.split(':');

        try {
            const client = new ImapFlow({
                host: host,
                port: parseInt(port) || 993,
                secure: true,
                auth: {
                    user: email,
                    pass: password
                },
                logger: false
            });

            await client.connect();
            
            // Try to select INBOX
            const lock = await client.getMailboxLock('INBOX');
            const status = await client.status('INBOX', { messages: true });
            lock.release();
            
            await client.logout();
            const responseTime = Date.now() - startTime;

            return {
                status: 'good',
                protocol: 'imap',
                server: server,
                responseTime: responseTime,
                message: `IMAP authentication successful. ${status.messages} messages in INBOX`,
                messageCount: status.messages
            };

        } catch (error) {
            const responseTime = Date.now() - startTime;
            return {
                status: 'bad',
                protocol: 'imap',
                server: server,
                responseTime: responseTime,
                message: error.message
            };
        }
    }
}

// Real Proxy checker
class ProxyChecker {
    static async checkProxy(host, port, type = 'http', username = null, password = null) {
        const startTime = Date.now();
        const testUrl = 'https://httpbin.org/ip';

        try {
            let agent;
            const proxyUrl = username && password 
                ? `${type}://${username}:${password}@${host}:${port}`
                : `${type}://${host}:${port}`;

            if (type.toLowerCase().startsWith('socks')) {
                agent = new SocksProxyAgent(proxyUrl);
            } else {
                agent = new HttpsProxyAgent(proxyUrl);
            }

            const response = await fetch(testUrl, {
                agent: agent,
                timeout: 15000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }

            const data = await response.json();
            const responseTime = Date.now() - startTime;

            // Get country info
            let country = 'Unknown';
            try {
                const geoResponse = await fetch(`http://ip-api.com/json/${data.origin}?fields=country`);
                const geoData = await geoResponse.json();
                country = geoData.country || 'Unknown';
            } catch (e) {
                console.log('Could not get country info:', e.message);
            }

            return {
                status: 'good',
                working: true,
                responseTime: responseTime,
                proxyIp: data.origin,
                country: country,
                type: type,
                message: 'Proxy is working'
            };

        } catch (error) {
            const responseTime = Date.now() - startTime;
            return {
                status: 'bad',
                working: false,
                responseTime: responseTime,
                message: error.message,
                type: type
            };
        }
    }
}

// Provider configurations
const EMAIL_PROVIDERS = {
    hotmail: {
        pop3: 'outlook.office365.com:995',
        smtp: 'smtp-mail.outlook.com:587',
        imap: 'outlook.office365.com:993'
    },
    yahoo: {
        pop3: 'pop.mail.yahoo.com:995',
        smtp: 'smtp.mail.yahoo.com:587',
        imap: 'imap.mail.yahoo.com:993'
    },
    gmail: {
        pop3: 'pop.gmail.com:995',
        smtp: 'smtp.gmail.com:587',
        imap: 'imap.gmail.com:993'
    }
};

// Utility function to detect email provider
function detectEmailProvider(email) {
    const domain = email.split('@')[1]?.toLowerCase();
    if (!domain) return 'unknown';
    
    if (domain.includes('hotmail') || domain.includes('outlook') || domain.includes('live')) {
        return 'hotmail';
    }
    if (domain.includes('yahoo')) {
        return 'yahoo';
    }
    if (domain.includes('gmail')) {
        return 'gmail';
    }
    return 'unknown';
}

// API Routes

// Authentication
app.post('/api/auth/register', async (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ error: 'Username and password required' });
    }

    try {
        const passwordHash = await bcrypt.hash(password, 10);
        const apiKey = require('crypto').randomBytes(32).toString('hex');

        db.run(
            'INSERT INTO users (username, password_hash, api_key) VALUES (?, ?, ?)',
            [username, passwordHash, apiKey],
            function(err) {
                if (err) {
                    if (err.message.includes('UNIQUE constraint failed')) {
                        return res.status(400).json({ error: 'Username already exists' });
                    }
                    return res.status(500).json({ error: 'Database error' });
                }

                const token = jwt.sign({ id: this.lastID, username }, JWT_SECRET, { expiresIn: '24h' });
                res.json({
                    message: 'User registered successfully',
                    token: token,
                    apiKey: apiKey,
                    userId: this.lastID
                });
            }
        );
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

app.post('/api/auth/login', async (req, res) => {
    const { username, password } = req.body;

    db.get('SELECT * FROM users WHERE username = ?', [username], async (err, user) => {
        if (err) return res.status(500).json({ error: 'Database error' });
        if (!user) return res.status(400).json({ error: 'Invalid credentials' });

        const validPassword = await bcrypt.compare(password, user.password_hash);
        if (!validPassword) return res.status(400).json({ error: 'Invalid credentials' });

        const token = jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, { expiresIn: '24h' });
        res.json({
            message: 'Login successful',
            token: token,
            apiKey: user.api_key,
            userId: user.id
        });
    });
});

// Email checking endpoints
app.post('/api/check-pop3', authenticateToken, async (req, res) => {
    const { email, password, server, proxy } = req.body;
    
    if (!email || !password) {
        return res.status(400).json({ error: 'Email and password required' });
    }

    try {
        let serverToUse = server;
        if (!serverToUse) {
            const provider = detectEmailProvider(email);
            serverToUse = EMAIL_PROVIDERS[provider]?.pop3;
            if (!serverToUse) {
                return res.status(400).json({ error: 'Unknown email provider' });
            }
        }

        const result = await POP3Checker.checkAccount(email, password, serverToUse, proxy);
        
        // Save result to database
        db.run(
            'INSERT INTO check_results (user_id, email, protocol, status, error_message, response_time, proxy_used) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [req.user.id, email, 'pop3', result.status, result.message, result.responseTime, proxy ? JSON.stringify(proxy) : null]
        );

        res.json(result);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.post('/api/check-smtp', authenticateToken, async (req, res) => {
    const { email, password, server, proxy } = req.body;
    
    if (!email || !password) {
        return res.status(400).json({ error: 'Email and password required' });
    }

    try {
        let serverToUse = server;
        if (!serverToUse) {
            const provider = detectEmailProvider(email);
            serverToUse = EMAIL_PROVIDERS[provider]?.smtp;
            if (!serverToUse) {
                return res.status(400).json({ error: 'Unknown email provider' });
            }
        }

        const result = await SMTPChecker.checkAccount(email, password, serverToUse, proxy);
        
        // Save result to database
        db.run(
            'INSERT INTO check_results (user_id, email, protocol, status, error_message, response_time, proxy_used) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [req.user.id, email, 'smtp', result.status, result.message, result.responseTime, proxy ? JSON.stringify(proxy) : null]
        );

        res.json(result);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.post('/api/check-imap', authenticateToken, async (req, res) => {
    const { email, password, server, proxy } = req.body;
    
    if (!email || !password) {
        return res.status(400).json({ error: 'Email and password required' });
    }

    try {
        let serverToUse = server;
        if (!serverToUse) {
            const provider = detectEmailProvider(email);
            serverToUse = EMAIL_PROVIDERS[provider]?.imap;
            if (!serverToUse) {
                return res.status(400).json({ error: 'Unknown email provider' });
            }
        }

        const result = await IMAPChecker.checkAccount(email, password, serverToUse, proxy);
        
        // Save result to database
        db.run(
            'INSERT INTO check_results (user_id, email, protocol, status, error_message, response_time, proxy_used) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [req.user.id, email, 'imap', result.status, result.message, result.responseTime, proxy ? JSON.stringify(proxy) : null]
        );

        res.json(result);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Batch email check endpoint
app.post('/api/check-emails-batch', authenticateToken, async (req, res) => {
    const { accounts, protocols, proxy } = req.body;
    
    if (!accounts || !Array.isArray(accounts)) {
        return res.status(400).json({ error: 'Accounts array required' });
    }

    const results = [];
    const enabledProtocols = protocols || ['pop3'];

    for (const account of accounts) {
        const { email, password } = account;
        const provider = detectEmailProvider(email);
        const servers = EMAIL_PROVIDERS[provider];

        if (!servers) {
            results.push({
                email: email,
                status: 'error',
                message: 'Unknown email provider'
            });
            continue;
        }

        const accountResults = {};

        for (const protocol of enabledProtocols) {
            try {
                let result;
                const server = servers[protocol];

                if (protocol === 'pop3') {
                    result = await POP3Checker.checkAccount(email, password, server, proxy);
                } else if (protocol === 'smtp') {
                    result = await SMTPChecker.checkAccount(email, password, server, proxy);
                } else if (protocol === 'imap') {
                    result = await IMAPChecker.checkAccount(email, password, server, proxy);
                }

                accountResults[protocol] = result;

                // Save to database
                db.run(
                    'INSERT INTO check_results (user_id, email, protocol, status, error_message, response_time, proxy_used) VALUES (?, ?, ?, ?, ?, ?, ?)',
                    [req.user.id, email, protocol, result.status, result.message, result.responseTime, proxy ? JSON.stringify(proxy) : null]
                );

            } catch (error) {
                accountResults[protocol] = {
                    status: 'error',
                    message: error.message
                };
            }
        }

        results.push({
            email: email,
            results: accountResults
        });
    }

    res.json({
        message: 'Batch check completed',
        results: results,
        totalChecked: accounts.length
    });
});

// Proxy checking endpoint
app.post('/api/check-proxy', authenticateToken, async (req, res) => {
    const { host, port, type, username, password } = req.body;
    
    if (!host || !port) {
        return res.status(400).json({ error: 'Host and port required' });
    }

    try {
        const result = await ProxyChecker.checkProxy(host, port, type, username, password);
        
        // Save proxy to database
        db.run(
            'INSERT OR REPLACE INTO proxy_servers (user_id, host, port, username, password, type, status, response_time, country, last_check) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime("now"))',
            [req.user.id, host, port, username, password, type, result.status, result.responseTime, result.country]
        );

        res.json(result);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Batch proxy check
app.post('/api/check-proxies-batch', authenticateToken, async (req, res) => {
    const { proxies } = req.body;
    
    if (!proxies || !Array.isArray(proxies)) {
        return res.status(400).json({ error: 'Proxies array required' });
    }

    const results = [];

    for (const proxy of proxies) {
        try {
            const result = await ProxyChecker.checkProxy(
                proxy.host, 
                proxy.port, 
                proxy.type || 'http', 
                proxy.username, 
                proxy.password
            );

            results.push({
                ...proxy,
                ...result
            });

            // Save to database
            db.run(
                'INSERT OR REPLACE INTO proxy_servers (user_id, host, port, username, password, type, status, response_time, country, last_check) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime("now"))',
                [req.user.id, proxy.host, proxy.port, proxy.username, proxy.password, proxy.type || 'http', result.status, result.responseTime, result.country]
            );

        } catch (error) {
            results.push({
                ...proxy,
                status: 'error',
                message: error.message
            });
        }
    }

    res.json({
        message: 'Batch proxy check completed',
        results: results,
        totalChecked: proxies.length
    });
});

// Get user's check history
app.get('/api/history', authenticateToken, (req, res) => {
    const limit = parseInt(req.query.limit) || 100;
    const offset = parseInt(req.query.offset) || 0;

    db.all(
        'SELECT * FROM check_results WHERE user_id = ? ORDER BY created_at DESC LIMIT ? OFFSET ?',
        [req.user.id, limit, offset],
        (err, rows) => {
            if (err) return res.status(500).json({ error: 'Database error' });
            res.json(rows);
        }
    );
});

// Get user's proxies
app.get('/api/proxies', authenticateToken, (req, res) => {
    db.all(
        'SELECT * FROM proxy_servers WHERE user_id = ? ORDER BY created_at DESC',
        [req.user.id],
        (err, rows) => {
            if (err) return res.status(500).json({ error: 'Database error' });
            res.json(rows);
        }
    );
});

// Health check
app.get('/api/health', (req, res) => {
    res.json({
        status: 'healthy',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        version: '1.0.0'
    });
});

// Error handler
app.use((err, req, res, next) => {
    console.error('Error:', err);
    res.status(500).json({ error: 'Internal server error' });
});

// 404 handler
app.use('*', (req, res) => {
    res.status(404).json({ error: 'Endpoint not found' });
});

// Start server
app.listen(PORT, () => {
    console.log(`🚀 Email Checker Server running on port ${PORT}`);
    console.log(`📧 Real POP3/IMAP/SMTP checking enabled`);
    console.log(`🌐 Real proxy checking enabled`);
    console.log(`💾 SQLite database initialized`);
    console.log(`🔐 JWT authentication enabled`);
});

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('\n🛑 Shutting down server...');
    db.close((err) => {
        if (err) {
            console.error('Error closing database:', err.message);
        } else {
            console.log('✅ Database connection closed');
        }
        process.exit(0);
    });
});