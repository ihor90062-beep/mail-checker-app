# Server Configuration
PORT=3000
NODE_ENV=production

# JWT Secret (CHANGE THIS IN PRODUCTION!)
JWT_SECRET=your-super-secret-jwt-key-change-this-in-production

# Database Configuration
DB_PATH=./email_checker.db

# API Rate Limiting
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=1000

# Proxy Test Settings
PROXY_TEST_URL=https://httpbin.org/ip
PROXY_TIMEOUT_MS=15000

# Email Check Settings
EMAIL_TIMEOUT_MS=30000
EMAIL_CONNECTION_TIMEOUT_MS=30000

# Security Settings
BCRYPT_SALT_ROUNDS=12
SESSION_TIMEOUT=24h

# Logging
LOG_LEVEL=info
LOG_FILE=./logs/server.log

# CORS Settings (comma separated origins)
ALLOWED_ORIGINS=http://localhost:3000,http://127.0.0.1:3000,https://yourdomain.com