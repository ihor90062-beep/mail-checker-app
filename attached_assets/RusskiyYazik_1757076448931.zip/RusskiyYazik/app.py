import os
import logging
import smtplib
import poplib
import imaplib
import socket
import requests
import threading
import time
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
import re
import dns.resolver
import json

# Configure logging
logging.basicConfig(level=logging.DEBUG)

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "default-secret-key-change-in-production")

# In-memory storage
users = {}
email_accounts = {}
proxy_servers = {}
check_results = []
current_checks = {}

def generate_txt_export(result_data):
    """Генерация TXT экспорта результатов"""
    content = f"Результаты проверки - {result_data['timestamp']}\n"
    content += "=" * 50 + "\n\n"
    
    if result_data['type'] == 'email':
        content += f"Тип: Проверка Email аккаунтов\n"
        content += f"Всего проверено: {result_data['total_checked']}\n"
        content += f"Успешных: {result_data['successful']}\n"
        content += f"Неудачных: {result_data['failed']}\n\n"
        
        for email_result in result_data['results']:
            content += f"Email: {email_result['email']}\n"
            for check in email_result['checks']:
                content += f"  {check['protocol']}: {check['status']} ({check['response_time']}ms) - {check['message']}\n"
            content += "\n"
    else:
        content += f"Тип: Проверка Прокси серверов\n"
        content += f"Всего проверено: {result_data['total_checked']}\n"
        content += f"Рабочих: {result_data['successful']}\n"
        content += f"Нерабочих: {result_data['failed']}\n\n"
        
        for proxy_result in result_data['results']:
            content += f"Прокси: {proxy_result['host']}:{proxy_result['port']}\n"
            content += f"  Статус: {proxy_result['status']}\n"
            content += f"  Время: {proxy_result['response_time']}ms\n"
            if proxy_result.get('proxy_ip'):
                content += f"  IP: {proxy_result['proxy_ip']}\n"
            if proxy_result.get('country'):
                content += f"  Страна: {proxy_result['country']}\n"
            content += "\n"
    
    return content

def generate_csv_export(result_data):
    """Генерация CSV экспорта результатов"""
    import io
    import csv
    
    output = io.StringIO()
    writer = csv.writer(output)
    
    if result_data['type'] == 'email':
        writer.writerow(['Email', 'POP3_Status', 'POP3_Time', 'SMTP_Status', 'SMTP_Time', 'IMAP_Status', 'IMAP_Time'])
        
        for email_result in result_data['results']:
            row = [email_result['email']]
            
            # Добавляем результаты для каждого протокола
            for protocol in ['POP3', 'SMTP', 'IMAP']:
                check = next((c for c in email_result['checks'] if c['protocol'] == protocol), None)
                if check:
                    row.extend([check['status'], check['response_time']])
                else:
                    row.extend(['', ''])
            
            writer.writerow(row)
    else:
        writer.writerow(['Host', 'Port', 'Type', 'Status', 'Response_Time', 'IP', 'Country'])
        
        for proxy_result in result_data['results']:
            writer.writerow([
                proxy_result['host'],
                proxy_result['port'],
                proxy_result.get('type', ''),
                proxy_result['status'],
                proxy_result['response_time'],
                proxy_result.get('proxy_ip', ''),
                proxy_result.get('country', '')
            ])
    
    return output.getvalue()

def parse_email_data(text, settings=None):
    """Улучшенный парсинг email данных с различными форматами"""
    if not settings:
        settings = {'email_format_detection': True, 'ignore_duplicates': True, 'case_sensitive': False}
    
    emails_data = []
    seen = set()
    
    # Автоопределение разделителей
    separators = [':']
    if settings.get('email_format_detection'):
        if '|' in text:
            separators = ['|']
        elif ';' in text:
            separators = [';']
        elif '\t' in text:
            separators = ['\t']
    
    # Пользовательские шаблоны
    custom_patterns = settings.get('extract_patterns', '').split('\n')
    for pattern in custom_patterns:
        if pattern.strip():
            separators.append(pattern.strip().replace('email', '').replace('pass', '').replace('password', ''))
    
    for line in text.split('\n'):
        line = line.strip()
        if not line:
            continue
            
        # Попробуем разные разделители
        for sep in separators:
            if sep in line:
                parts = line.split(sep, 1)
                if len(parts) == 2:
                    email = parts[0].strip()
                    password = parts[1].strip()
                    
                    # Валидация email
                    if validate_email_format(email):
                        # Проверка дубликатов
                        key = email.lower() if not settings.get('case_sensitive') else email
                        if not settings.get('ignore_duplicates') or key not in seen:
                            emails_data.append({'email': email, 'password': password})
                            seen.add(key)
                        break
    
    return emails_data

def validate_email_format(email):
    """Валидация формата email адреса"""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def validate_email_dns(email):
    """DNS валидация email домена"""
    try:
        domain = email.split('@')[1]
        mx_records = dns.resolver.resolve(domain, 'MX')
        return len(mx_records) > 0
    except:
        return False

def check_email_with_api(email, api_key, service='hunter'):
    """Проверка email через внешние API"""
    if not api_key:
        return None
        
    try:
        if service == 'hunter':
            url = f"https://api.hunter.io/v2/email-verifier?email={email}&api_key={api_key}"
            response = requests.get(url, timeout=10)
            if response.status_code == 200:
                data = response.json()
                return {
                    'status': data.get('data', {}).get('status', 'unknown'),
                    'score': data.get('data', {}).get('score', 0),
                    'result': data.get('data', {}).get('result', 'unknown')
                }
    except Exception as e:
        print(f"API error for {email}: {e}")
    
    return None

def get_proxy_geolocation(ip, api_key):
    """Получение геолокации прокси через API"""
    if not api_key:
        return None
        
    try:
        url = f"https://api.ipgeolocation.io/ipgeo?apiKey={api_key}&ip={ip}"
        response = requests.get(url, timeout=5)
        if response.status_code == 200:
            data = response.json()
            return {
                'country': data.get('country_name', 'Unknown'),
                'city': data.get('city', 'Unknown'),
                'region': data.get('state_prov', 'Unknown'),
                'isp': data.get('isp', 'Unknown')
            }
    except Exception as e:
        print(f"Geolocation API error for {ip}: {e}")
    
    return None

def check_proxy_quality(host, port, api_key):
    """Проверка качества прокси через API"""
    if not api_key:
        return None
        
    try:
        url = f"https://proxycheck.io/v2/{host}?key={api_key}&vpn=1&asn=1"
        response = requests.get(url, timeout=10)
        if response.status_code == 200:
            data = response.json()
            proxy_data = data.get(host, {})
            return {
                'type': proxy_data.get('type', 'unknown'),
                'provider': proxy_data.get('provider', 'unknown'),
                'country': proxy_data.get('country', 'unknown'),
                'risk_score': proxy_data.get('risk', 0)
            }
    except Exception as e:
        print(f"Proxy quality API error for {host}: {e}")
    
    return None

def calculate_user_statistics(user_results):
    """Расчет статистики пользователя"""
    stats = {
        'total_checks': len(user_results),
        'email_checks': len([r for r in user_results if r['type'] == 'email']),
        'proxy_checks': len([r for r in user_results if r['type'] == 'proxy']),
        'total_accounts_checked': sum(r.get('total_checked', 0) for r in user_results),
        'total_successful': sum(r.get('successful', 0) for r in user_results),
        'total_failed': sum(r.get('failed', 0) for r in user_results),
        'success_rate': 0,
        'recent_checks': user_results[:5] if user_results else [],
        'daily_stats': {},
        'hourly_stats': {}
    }
    
    if stats['total_accounts_checked'] > 0:
        stats['success_rate'] = round((stats['total_successful'] / stats['total_accounts_checked']) * 100, 1)
    
    # Статистика по дням
    for result in user_results:
        date = result['timestamp'].split(' ')[0]
        if date not in stats['daily_stats']:
            stats['daily_stats'][date] = {'checks': 0, 'successful': 0, 'failed': 0}
        
        stats['daily_stats'][date]['checks'] += result.get('total_checked', 0)
        stats['daily_stats'][date]['successful'] += result.get('successful', 0)
        stats['daily_stats'][date]['failed'] += result.get('failed', 0)
    
    return stats

# Email provider configurations
EMAIL_PROVIDERS = {
    'hotmail': {
        'pop3': ('outlook.office365.com', 995),
        'smtp': ('smtp-mail.outlook.com', 587),
        'imap': ('outlook.office365.com', 993)
    },
    'yahoo': {
        'pop3': ('pop.mail.yahoo.com', 995),
        'smtp': ('smtp.mail.yahoo.com', 587),
        'imap': ('imap.mail.yahoo.com', 993)
    },
    'gmail': {
        'pop3': ('pop.gmail.com', 995),
        'smtp': ('smtp.gmail.com', 587),
        'imap': ('imap.gmail.com', 993)
    }
}

def detect_email_provider(email):
    """Определяет провайдера email по домену"""
    domain = email.split('@')[1].lower() if '@' in email else ''
    
    if any(x in domain for x in ['hotmail', 'outlook', 'live']):
        return 'hotmail'
    elif 'yahoo' in domain:
        return 'yahoo'
    elif 'gmail' in domain:
        return 'gmail'
    else:
        return 'unknown'

def check_pop3_account(email, password, host, port, settings=None):
    """Проверка POP3 аккаунта"""
    start_time = time.time()
    try:
        server = poplib.POP3_SSL(host, port, timeout=30)
        server.user(email)
        server.pass_(password)
        message_count, mailbox_size = server.stat()
        server.quit()
        
        response_time = int((time.time() - start_time) * 1000)
        return {
            'status': 'good',
            'protocol': 'POP3',
            'message': f'Успешно подключен. Сообщений: {message_count}',
            'response_time': response_time
        }
    except Exception as e:
        response_time = int((time.time() - start_time) * 1000)
        return {
            'status': 'bad',
            'protocol': 'POP3',
            'message': f'Ошибка: {str(e)}',
            'response_time': response_time
        }

def check_smtp_account(email, password, host, port, settings=None):
    """Проверка SMTP аккаунта"""
    start_time = time.time()
    try:
        server = smtplib.SMTP(host, port, timeout=30)
        server.starttls()
        server.login(email, password)
        server.quit()
        
        response_time = int((time.time() - start_time) * 1000)
        return {
            'status': 'good',
            'protocol': 'SMTP',
            'message': 'SMTP аутентификация успешна',
            'response_time': response_time
        }
    except Exception as e:
        response_time = int((time.time() - start_time) * 1000)
        return {
            'status': 'bad',
            'protocol': 'SMTP',
            'message': f'Ошибка: {str(e)}',
            'response_time': response_time
        }

def check_imap_account(email, password, host, port, settings=None):
    """Проверка IMAP аккаунта"""
    start_time = time.time()
    try:
        server = imaplib.IMAP4_SSL(host, port, timeout=30)
        server.login(email, password)
        server.select('INBOX')
        status, messages = server.search(None, 'ALL')
        message_count = len(messages[0].split()) if messages[0] else 0
        server.logout()
        
        response_time = int((time.time() - start_time) * 1000)
        return {
            'status': 'good',
            'protocol': 'IMAP',
            'message': f'Успешно подключен. Сообщений: {message_count}',
            'response_time': response_time,
            'message_count': message_count
        }
    except Exception as e:
        response_time = int((time.time() - start_time) * 1000)
        return {
            'status': 'bad',
            'protocol': 'IMAP',
            'message': f'Ошибка: {str(e)}',
            'response_time': response_time
        }

def check_proxy_server(host, port, proxy_type='http', username=None, password=None):
    """Проверка прокси сервера"""
    start_time = time.time()
    try:
        
        # Формируем URL прокси
        if username and password:
            proxy_url = f"{proxy_type}://{username}:{password}@{host}:{port}"
        else:
            proxy_url = f"{proxy_type}://{host}:{port}"
        
        proxies = {
            'http': proxy_url,
            'https': proxy_url
        }
        
        # Тестируем прокси
        response = requests.get('https://httpbin.org/ip', 
                              proxies=proxies, 
                              timeout=15,
                              headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'})
        
        if response.status_code == 200:
            data = response.json()
            proxy_ip = data.get('origin', 'Unknown')
            
            # Получаем информацию о стране
            try:
                geo_response = requests.get(f'http://ip-api.com/json/{proxy_ip}?fields=country', timeout=5)
                geo_data = geo_response.json()
                country = geo_data.get('country', 'Неизвестно')
            except:
                country = 'Неизвестно'
            
            response_time = int((time.time() - start_time) * 1000)
            return {
                'status': 'good',
                'message': 'Прокси работает',
                'response_time': response_time,
                'proxy_ip': proxy_ip,
                'country': country
            }
        else:
            response_time = int((time.time() - start_time) * 1000)
            return {
                'status': 'bad',
                'message': f'HTTP {response.status_code}',
                'response_time': response_time
            }
            
    except Exception as e:
        response_time = int((time.time() - start_time) * 1000)
        return {
            'status': 'bad',
            'message': f'Ошибка: {str(e)}',
            'response_time': response_time
        }

def perform_email_check(check_id, emails_data, protocols):
    """Выполняет проверку email аккаунтов в отдельном потоке"""
    results = []
    total = len(emails_data)
    
    # Получаем настройки пользователя для API интеграции
    username = session.get('username', '')
    user_settings = users.get(username, {}).get('settings', {})
    
    current_checks[check_id] = {
        'total': total,
        'completed': 0,
        'results': [],
        'status': 'running'
    }
    
    for i, email_data in enumerate(emails_data):
        email = email_data['email']
        password = email_data['password']
        provider = detect_email_provider(email)
        
        email_results = {'email': email, 'checks': []}
        
        # Предварительная API проверка email если настроен ключ
        api_result = None
        if user_settings.get('hunter_api_key'):
            api_result = check_email_with_api(email, user_settings['hunter_api_key'])
        
        if provider in EMAIL_PROVIDERS:
            config = EMAIL_PROVIDERS[provider]
            
            if 'pop3' in protocols:
                host, port = config['pop3']
                result = check_pop3_account(email, password, host, port, user_settings)
                result['timestamp'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                if api_result:
                    result['api_verification'] = api_result
                email_results['checks'].append(result)
            
            if 'smtp' in protocols:
                host, port = config['smtp']
                result = check_smtp_account(email, password, host, port, user_settings)
                result['timestamp'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                if api_result:
                    result['api_verification'] = api_result
                email_results['checks'].append(result)
            
            if 'imap' in protocols:
                host, port = config['imap']
                result = check_imap_account(email, password, host, port, user_settings)
                result['timestamp'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                if api_result:
                    result['api_verification'] = api_result
                email_results['checks'].append(result)
        else:
            email_results['checks'].append({
                'status': 'bad',
                'protocol': 'Unknown',
                'message': 'Неизвестный провайдер email',
                'response_time': 0,
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            })
        
        results.append(email_results)
        current_checks[check_id]['completed'] = i + 1
        current_checks[check_id]['results'] = results
    
    current_checks[check_id]['status'] = 'completed'
    check_results.append({
        'id': check_id,
        'type': 'email',
        'user_id': session.get('user_id'),
        'username': session.get('username'),
        'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'results': results,
        'total_checked': len(results),
        'successful': len([r for r in results if any(c['status'] == 'good' for c in r['checks'])]),
        'failed': len([r for r in results if all(c['status'] != 'good' for c in r['checks'])])
    })

def perform_proxy_check(check_id, proxies_data):
    """Выполняет проверку прокси серверов в отдельном потоке"""
    results = []
    total = len(proxies_data)
    
    current_checks[check_id] = {
        'total': total,
        'completed': 0,
        'results': [],
        'status': 'running'
    }
    
    for i, proxy_data in enumerate(proxies_data):
        host = proxy_data['host']
        port = int(proxy_data['port'])
        proxy_type = proxy_data.get('type', 'http')
        username = proxy_data.get('username')
        password = proxy_data.get('password')
        
        result = check_proxy_server(host, port, proxy_type, username, password)
        result['host'] = host
        result['port'] = port
        result['type'] = proxy_type
        result['timestamp'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        results.append(result)
        current_checks[check_id]['completed'] = i + 1
        current_checks[check_id]['results'] = results
    
    current_checks[check_id]['status'] = 'completed'
    check_results.append({
        'id': check_id,
        'type': 'proxy',
        'user_id': session.get('user_id'),
        'username': session.get('username'),
        'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'results': results,
        'total_checked': len(results),
        'successful': len([r for r in results if r['status'] == 'good']),
        'failed': len([r for r in results if r['status'] != 'good'])
    })

@app.route('/')
def index():
    if 'username' not in session:
        return redirect(url_for('login'))
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        if username in users and check_password_hash(users[username]['password_hash'], password):
            session['username'] = username
            session['user_id'] = users[username]['id']
            flash('Вход выполнен успешно!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Неверное имя пользователя или пароль', 'error')
    
    return render_template('login.html')

@app.route('/register', methods=['POST'])
def register():
    username = request.form['username']
    password = request.form['password']
    
    if username in users:
        flash('Пользователь уже существует', 'error')
        return redirect(url_for('login'))
    
    users[username] = {
        'id': len(users) + 1,
        'username': username,
        'password_hash': generate_password_hash(password),
        'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    }
    
    session['username'] = username
    session['user_id'] = users[username]['id']
    flash('Регистрация прошла успешно!', 'success')
    return redirect(url_for('index'))

@app.route('/logout')
def logout():
    session.clear()
    flash('Вы вышли из системы', 'info')
    return redirect(url_for('login'))

@app.route('/email_check', methods=['GET', 'POST'])
def email_check():
    if 'username' not in session:
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        emails_data = []
        protocols = request.form.getlist('protocols')
        
        if not protocols:
            flash('Пожалуйста, выберите протоколы для проверки', 'error')
            return render_template('email_check.html')
        
        # Проверяем наличие файла
        if 'email_file' in request.files and request.files['email_file'].filename:
            file = request.files['email_file']
            if file.filename and file.filename.endswith(('.txt', '.list')):
                content = file.read().decode('utf-8')
                # Получаем настройки пользователя для парсинга
                user_settings = users.get(session['username'], {}).get('settings', {})
                emails_data = parse_email_data(content, user_settings)
            else:
                flash('Поддерживаются только файлы .txt и .list', 'error')
                return render_template('email_check.html')
        else:
            # Парсинг из текстового поля с улучшенной логикой
            emails_text = request.form.get('emails', '').strip()
            if not emails_text:
                flash('Пожалуйста, введите email адреса или загрузите файл', 'error')
                return render_template('email_check.html')
            
            # Получаем настройки пользователя для парсинга
            user_settings = users.get(session['username'], {}).get('settings', {})
            emails_data = parse_email_data(emails_text, user_settings)
        
        if not emails_data:
            flash('Не найдены валидные email:password пары', 'error')
            return render_template('email_check.html')
        
        # Запуск проверки в отдельном потоке
        check_id = f"email_{int(time.time())}"
        thread = threading.Thread(target=perform_email_check, args=(check_id, emails_data, protocols))
        thread.daemon = True
        thread.start()
        
        flash(f'Запущена проверка {len(emails_data)} email аккаунтов', 'info')
        return redirect(url_for('check_progress', check_id=check_id))
    
    return render_template('email_check.html')

@app.route('/proxy_check', methods=['GET', 'POST'])
def proxy_check():
    if 'username' not in session:
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        proxies_data = []
        proxy_type = request.form.get('proxy_type', 'http')
        
        # Проверяем наличие файла
        if 'proxy_file' in request.files and request.files['proxy_file'].filename:
            file = request.files['proxy_file']
            if file.filename and file.filename.endswith(('.txt', '.list')):
                content = file.read().decode('utf-8')
                for line in content.split('\n'):
                    line = line.strip()
                    if ':' in line:
                        parts = line.split(':')
                        if len(parts) >= 2:
                            proxy_data = {
                                'host': parts[0].strip(),
                                'port': parts[1].strip(),
                                'type': proxy_type
                            }
                            if len(parts) >= 4:  # host:port:username:password
                                proxy_data['username'] = parts[2].strip()
                                proxy_data['password'] = parts[3].strip()
                            proxies_data.append(proxy_data)
            else:
                flash('Поддерживаются только файлы .txt и .list', 'error')
                return render_template('proxy_check.html')
        else:
            # Парсинг из текстового поля
            proxies_text = request.form.get('proxies', '').strip()
            if not proxies_text:
                flash('Пожалуйста, введите прокси серверы или загрузите файл', 'error')
                return render_template('proxy_check.html')
            
            for line in proxies_text.split('\n'):
                line = line.strip()
                if ':' in line:
                    parts = line.split(':')
                    if len(parts) >= 2:
                        proxy_data = {
                            'host': parts[0].strip(),
                            'port': parts[1].strip(),
                            'type': proxy_type
                        }
                        if len(parts) >= 4:  # host:port:username:password
                            proxy_data['username'] = parts[2].strip()
                            proxy_data['password'] = parts[3].strip()
                        proxies_data.append(proxy_data)
        
        if not proxies_data:
            flash('Не найдены валидные прокси серверы', 'error')
            return render_template('proxy_check.html')
        
        # Запуск проверки в отдельном потоке
        check_id = f"proxy_{int(time.time())}"
        thread = threading.Thread(target=perform_proxy_check, args=(check_id, proxies_data))
        thread.daemon = True
        thread.start()
        
        flash(f'Запущена проверка {len(proxies_data)} прокси серверов', 'info')
        return redirect(url_for('check_progress', check_id=check_id))
    
    return render_template('proxy_check.html')

@app.route('/check_progress/<check_id>')
def check_progress(check_id):
    if 'username' not in session:
        return redirect(url_for('login'))
    
    if check_id not in current_checks:
        flash('Проверка не найдена', 'error')
        return redirect(url_for('index'))
    
    check_data = current_checks[check_id]
    if check_data['status'] == 'completed':
        return redirect(url_for('results', check_id=check_id))
    
    return render_template('results.html', check_data=check_data, check_id=check_id, in_progress=True)

@app.route('/results/<check_id>')
def results(check_id):
    if 'username' not in session:
        return redirect(url_for('login'))
    
    # Поиск результатов в истории
    result_data = None
    for result in check_results:
        if result['id'] == check_id:
            result_data = result
            break
    
    if not result_data:
        flash('Результаты не найдены', 'error')
        return redirect(url_for('index'))
    
    return render_template('results.html', result_data=result_data, check_id=check_id, in_progress=False)

@app.route('/api/check_status/<check_id>')
def api_check_status(check_id):
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    if check_id not in current_checks:
        return jsonify({'error': 'Check not found'}), 404
    
    return jsonify(current_checks[check_id])

@app.route('/history')
def history():
    if 'username' not in session:
        return redirect(url_for('login'))
    
    user_id = session.get('user_id')
    user_results = [r for r in check_results if r.get('user_id') == user_id]
    
    return render_template('history.html', results=user_results[::-1])  # Последние сначала

@app.route('/export/<check_id>/<format>')
def export_results(check_id, format):
    if 'username' not in session:
        return redirect(url_for('login'))
    
    # Найти результаты
    result_data = None
    for result in check_results:
        if result['id'] == check_id:
            result_data = result
            break
    
    if not result_data:
        flash('Результаты не найдены', 'error')
        return redirect(url_for('history'))
    
    from flask import make_response
    import csv
    import io
    
    if format == 'txt':
        content = generate_txt_export(result_data)
        response = make_response(content)
        response.headers['Content-Type'] = 'text/plain; charset=utf-8'
        response.headers['Content-Disposition'] = f'attachment; filename=results_{check_id}.txt'
        
    elif format == 'csv':
        content = generate_csv_export(result_data)
        response = make_response(content)
        response.headers['Content-Type'] = 'text/csv; charset=utf-8'
        response.headers['Content-Disposition'] = f'attachment; filename=results_{check_id}.csv'
        
    elif format == 'json':
        import json
        content = json.dumps(result_data, ensure_ascii=False, indent=2)
        response = make_response(content)
        response.headers['Content-Type'] = 'application/json; charset=utf-8'
        response.headers['Content-Disposition'] = f'attachment; filename=results_{check_id}.json'
    else:
        flash('Неподдерживаемый формат экспорта', 'error')
        return redirect(url_for('history'))
    
    return response

@app.route('/statistics')
def statistics():
    if 'username' not in session:
        return redirect(url_for('login'))
    
    user_id = session.get('user_id')
    user_results = [r for r in check_results if r.get('user_id') == user_id]
    
    # Подсчет статистики
    stats = calculate_user_statistics(user_results)
    
    return render_template('statistics.html', stats=stats)

@app.route('/settings', methods=['GET', 'POST'])
def settings():
    if 'username' not in session:
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        # Сохранение настроек пользователя
        user_settings = {
            'timeout': int(request.form.get('timeout', 30)),
            'concurrent_checks': int(request.form.get('concurrent_checks', 5)),
            'retry_attempts': int(request.form.get('retry_attempts', 2)),
            # API Settings
            'hunter_api_key': request.form.get('hunter_api_key', ''),
            'ipgeolocation_api_key': request.form.get('ipgeolocation_api_key', ''),
            'proxy_check_api': request.form.get('proxy_check_api', ''),
            'custom_api_endpoint': request.form.get('custom_api_endpoint', ''),
            # HTTPS Settings
            'verify_ssl': 'verify_ssl' in request.form,
            'ssl_timeout': int(request.form.get('ssl_timeout', 10)),
            'user_agent': request.form.get('user_agent', 'EmailProxyChecker/1.0'),
            'follow_redirects': 'follow_redirects' in request.form,
            # Email Parsing Settings
            'email_validation_level': request.form.get('email_validation_level', 'dns'),
            'email_format_detection': 'email_format_detection' in request.form,
            'extract_patterns': request.form.get('extract_patterns', ''),
            'ignore_duplicates': 'ignore_duplicates' in request.form,
            'case_sensitive': 'case_sensitive' in request.form
        }
        
        # Сохранение в памяти (в реальном приложении - в БД)
        username = session['username']
        if username not in users:
            users[username] = {}
        users[username]['settings'] = user_settings
        
        flash('Настройки сохранены', 'success')
    
    user_settings = users.get(session['username'], {}).get('settings', {
        'timeout': 30,
        'concurrent_checks': 5,
        'retry_attempts': 2,
        # API Settings
        'hunter_api_key': '',
        'ipgeolocation_api_key': '',
        'proxy_check_api': '',
        'custom_api_endpoint': '',
        # HTTPS Settings
        'verify_ssl': True,
        'ssl_timeout': 10,
        'user_agent': 'EmailProxyChecker/1.0',
        'follow_redirects': True,
        # Email Parsing Settings
        'email_validation_level': 'dns',
        'email_format_detection': True,
        'extract_patterns': '',
        'ignore_duplicates': True,
        'case_sensitive': False
    })
    
    return render_template('settings.html', settings=user_settings)

# API Routes for new functionality
@app.route('/api/http-request', methods=['POST'])
def api_http_request():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    data = request.get_json()
    method = data.get('method', 'GET')
    url = data.get('url')
    headers_text = data.get('headers', '')
    body = data.get('body', '')
    verify_ssl = data.get('verify_ssl', True)
    
    if not url:
        return jsonify({'error': 'URL is required'}), 400
    
    try:
        # Parse headers
        headers = {}
        if headers_text:
            for line in headers_text.split('\n'):
                if ':' in line:
                    key, value = line.split(':', 1)
                    headers[key.strip()] = value.strip()
        
        # Make request
        response = requests.request(
            method=method,
            url=url,
            headers=headers,
            data=body if body else None,
            verify=verify_ssl,
            timeout=30
        )
        
        return jsonify({
            'status_code': response.status_code,
            'headers': dict(response.headers),
            'body': response.text,
            'time': response.elapsed.total_seconds()
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/parse-email', methods=['POST'])
def api_parse_email():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    data = request.get_json()
    text = data.get('text', '')
    auto_detect = data.get('auto_detect', True)
    validate_email = data.get('validate_email', True)
    remove_duplicates = data.get('remove_duplicates', True)
    
    settings = {
        'email_format_detection': auto_detect,
        'ignore_duplicates': remove_duplicates,
        'case_sensitive': False
    }
    
    try:
        results = parse_email_data(text, settings)
        
        # Validate emails if requested
        if validate_email:
            valid_results = []
            for item in results:
                if validate_email_format(item['email']):
                    valid_results.append(item)
            results = valid_results
        
        return jsonify({
            'count': len(results),
            'results': results
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/export-database')
def api_export_database():
    if 'username' not in session:
        return redirect(url_for('login'))
    
    user_id = session.get('user_id')
    user_results = [r for r in check_results if r.get('user_id') == user_id]
    
    import json
    content = json.dumps(user_results, ensure_ascii=False, indent=2)
    
    from flask import make_response
    response = make_response(content)
    response.headers['Content-Type'] = 'application/json; charset=utf-8'
    response.headers['Content-Disposition'] = 'attachment; filename=database_export.json'
    
    return response

@app.route('/api/sql-query', methods=['POST'])
def api_sql_query():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    data = request.get_json()
    query = data.get('query', '').strip().lower()
    
    # Basic SQL simulation using in-memory data
    try:
        user_id = session.get('user_id')
        user_results = [r for r in check_results if r.get('user_id') == user_id]
        
        if 'select' in query and 'check_results' in query:
            # Simulate basic SELECT queries
            results = []
            for result in user_results:
                row = {
                    'id': result.get('id'),
                    'type': result.get('type'),
                    'timestamp': result.get('timestamp'),
                    'total_checked': result.get('total_checked', 0),
                    'successful': result.get('successful', 0),
                    'failed': result.get('failed', 0)
                }
                results.append(row)
            
            # Apply LIMIT if present
            if 'limit' in query:
                import re
                limit_match = re.search(r'limit\s+(\d+)', query)
                if limit_match:
                    limit = int(limit_match.group(1))
                    results = results[:limit]
            
            return jsonify({'results': results})
        else:
            return jsonify({'error': 'Only SELECT queries on check_results are supported'}), 400
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/clear-all-data', methods=['POST'])
def api_clear_all_data():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        user_id = session.get('user_id')
        
        # Clear user's check results
        global check_results
        check_results = [r for r in check_results if r.get('user_id') != user_id]
        
        # Clear current checks
        global current_checks
        user_checks = [k for k, v in current_checks.items() if k.startswith(f"email_{user_id}") or k.startswith(f"proxy_{user_id}")]
        for check_id in user_checks:
            del current_checks[check_id]
        
        return jsonify({'message': 'Все данные пользователя успешно очищены'})
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
