# Overview

This is an Advanced Email & Proxy Checker application built with Flask. The system provides a web-based interface for testing email accounts across multiple protocols (POP3, IMAP, SMTP) and validating proxy servers. It includes user authentication, batch processing capabilities, and real-time progress tracking.

The application supports major email providers (Gmail, Yahoo, Hotmail/Outlook) and various proxy types (HTTP/HTTPS, SOCKS4, SOCKS5). It features a modern web interface with Bootstrap styling and provides comprehensive validation results with detailed statistics.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Template Engine**: Jinja2 templates with Flask
- **UI Framework**: Bootstrap 5 with dark theme support
- **Styling**: Custom CSS with hover effects and responsive design
- **JavaScript**: Vanilla JavaScript for form validation, auto-refresh, and interactive features
- **Icons**: Font Awesome for consistent iconography

## Backend Architecture
- **Web Framework**: Flask with session-based authentication
- **Data Storage**: In-memory dictionaries for user data, email accounts, proxy servers, and check results
- **Authentication**: Werkzeug password hashing with session management
- **Email Protocols**: Native Python libraries (smtplib, poplib, imaplib) for email validation
- **Concurrency**: Threading for background email/proxy checking operations
- **Logging**: Built-in Python logging for debugging and monitoring

## Core Components
- **User Management**: Registration and login system with password hashing
- **Email Provider Detection**: Automatic configuration for major email providers
- **Protocol Testing**: Support for POP3, IMAP, and SMTP validation
- **Proxy Validation**: HTTP/HTTPS and SOCKS proxy testing capabilities
- **Batch Processing**: Concurrent checking of multiple accounts/proxies
- **Progress Tracking**: Real-time status updates for long-running operations

## Security Features
- **Password Security**: Werkzeug password hashing for user accounts
- **Session Management**: Flask sessions with configurable secret key
- **Input Validation**: Server-side validation for email and proxy formats
- **Error Handling**: Comprehensive exception handling for network operations

# External Dependencies

## Python Libraries
- **Flask**: Web framework and template rendering
- **Werkzeug**: Password hashing and security utilities
- **smtplib/poplib/imaplib**: Native email protocol libraries
- **socket**: Low-level network operations for proxy testing
- **requests**: HTTP client for web-based validations
- **threading**: Concurrent processing support

## Frontend Dependencies
- **Bootstrap 5**: UI framework via CDN
- **Font Awesome**: Icon library via CDN
- **Custom CSS/JS**: Local static assets for enhanced functionality

## Email Provider Configurations
- **Gmail**: POP3, SMTP, and IMAP server configurations
- **Yahoo**: Complete protocol support with proper server endpoints
- **Hotmail/Outlook**: Microsoft email service integration

## Network Services
- **Email Servers**: Direct connections to provider SMTP/POP3/IMAP servers
- **Proxy Servers**: Support for HTTP, HTTPS, SOCKS4, and SOCKS5 proxies
- **SSL/TLS**: Secure connections for email protocol validation

Note: The application currently uses in-memory storage, which means data is not persistent across server restarts. A database integration (such as PostgreSQL with an ORM like Drizzle) could be added for persistent data storage.